# Figures 13–14: distance bounds for the weight-six MM [[216,6]] code

Run from the unpacked folder with the QECC Python environment active (Python 3.10+ and h5py). One CPU is sufficient.

    set -o pipefail
    python -u verify.py 2>&1 | tee verify.log

The script checks the SHA-256 hashes in sources.json. The two archived files come from QuantumSavory/Multivariate-Multicycle-Codes-For-Complete-Single-Shot-Decoding at the indicated commit. The "12" in the archived filenames is a historical label, not a distance certificate.

For this particular LRC circuit, data qubits are numbered 0 through 215. Each ancilla is reset, coupled by CX to six distinct data qubits, and read out in its preparation basis. The script expands the repeat block, extracts every measured support, checks all 24 rounds, then compares the X and Z rows (including multiplicities) to the HDF5 input up to row ordering. It checks CSS commutation and computes both binary ranks by XOR elimination. The bundled circuit is one archived LRC realization, not a reconstruction of the default schedule.

For each sector, the script looks for two triples with the same syndrome. Their symmetric difference has syndrome zero. The candidate is accepted only if it lies outside the row space of the same-sector stabilizers, and the checks are repeated using the HDF5 rows. The JSON output records zero-based physical qubit indices, weights, input hashes, ranks, hostname and UTC time. This is an upper-bound calculation, not a proof that weight six is minimal. It neither decodes shots nor estimates a circuit distance. Upload your own run's JSON and log with the script and source manifest.
