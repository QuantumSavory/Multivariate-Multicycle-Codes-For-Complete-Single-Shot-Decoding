"""Verify weight-six logicals against the archived Figure 13/14 instance."""
import csv, hashlib, json, socket, sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from itertools import combinations
from pathlib import Path
import h5py
N=216
base=Path(__file__).resolve().parent
def check(ok,msg):
    if not ok: raise ValueError(msg)
def packed(ids):
    return sum(1<<int(i) for i in ids)
def support(x):
    return [i for i in range(N) if x>>i&1]
def basis(rows):
    b={}
    for x in rows:
        while x and x.bit_length() in b: x ^= b[x.bit_length()]
        if x: b[x.bit_length()]=x
    return b
def outside(x,b):
    while x:
        p=x.bit_length()
        if p not in b: return True
        x ^= b[p]
    return False
def expanded(lines):
    it=iter(lines)
    for line in it:
        line=line.strip()
        if line.startswith('REPEAT '):
            num=int(line.split()[1]); block=[]
            for v in it:
                if v.strip()=='}': break
                check('REPEAT' not in v,'nested repeat unsupported')
                block.append(v)
            for _ in range(num): yield from expanded(block)
        elif line: yield line
def circuit_checks(path):
    active={}; records=defaultdict(list)
    for line in expanded(path.read_text().splitlines()):
        op,*v=line.split()
        if op not in ('R','RX','CX','M','MX'): continue
        ids=list(map(int,v))
        if op=='CX':
            for c,t in zip(ids[::2],ids[1::2],strict=True):
                check((c<N)!=(t<N),'expected ancilla/data CX')
                a,d,kind=(c,t,'X') if c>=N else (t,c,'Z')
                check(active[a][0]==kind,'reset/CX basis mismatch')
                active[a][1].append(d)
        else:
            for a in ids:
                if a<N: continue
                if op in ('R','RX'):
                    check(a not in active,'reset before readout')
                    active[a]=('X' if op=='RX' else 'Z',[])
                else:
                    kind,ds=active.pop(a)
                    check(kind==('X' if op=='MX' else 'Z'),'readout basis mismatch')
                    check(len(ds)==len(set(ds))==6,'expected six distinct data partners')
                    records[kind,a].append(packed(ds))
    check(not active and records,'incomplete circuit')
    check(all(len(rr)==24 and len(set(rr))==1 for rr in records.values()),'rounds/checks differ')
    return {k:[rr[0] for (s,a),rr in records.items() if k==s] for k in 'XZ'}
def witness(checks,stabs):
    cols=[packed(j for j,h in enumerate(checks) if h>>i&1) for i in range(N)]
    b=basis(stabs); seen={}
    for i,j,k in combinations(range(N),3):
        s=cols[i]^cols[j]^cols[k]; u=(1<<i)|(1<<j)|(1<<k)
        v=seen.setdefault(s,u); e=u^v
        if e and outside(e,b):
            check(e.bit_count()<=6 and all((e&h).bit_count()%2==0 for h in checks),'invalid logical')
            return e
    raise ValueError('no witness found')
def main():
    src=json.loads((base/'sources.json').read_text()); paths={}
    for p,sha in src['sha256'].items():
        f=base/'inputs'/Path(p).name
        check(hashlib.sha256(f.read_bytes()).hexdigest()==sha,'input hash mismatch')
        paths[f.suffix]=f
    measured=circuit_checks(paths['.stim']); H={}
    with h5py.File(paths['.h5']) as f:
        for s in 'XZ':
            a=f['parity_matrix_'+s.lower()][:].T
            check(a.shape==(144,N) and ((a==0)|(a==1)).all(),'unexpected HDF5 matrix')
            H[s]=[packed(row.nonzero()[0]) for row in a]
            check(Counter(H[s])==Counter(measured[s]),'measured/HDF5 '+s+' rows differ')
    check(all((x&z).bit_count()%2==0 for x in H['X'] for z in H['Z']),'noncommuting checks')
    ranks={s:len(basis(h)) for s,h in H.items()}
    check(N-sum(ranks.values())==6,'unexpected k')
    print('PASS: both measured check multisets equal HDF5 in every one of 24 rounds; ranks',ranks)
    result=dict(source=src,host=socket.gethostname(),utc=datetime.now(timezone.utc).isoformat(),n=N,k=6,ranks=ranks,rounds=24,check_weight=6,witnesses={})
    for s,t in [('X','Z'),('Z','X')]:
        e=witness(measured[t],measured[s])
        ok=all((e&h).bit_count()%2==0 for h in H[t]) and outside(e,basis(H[s]))
        check(ok,'independent HDF5 witness check failed')
        result['witnesses'][s]=dict(support_zero_based=support(e),weight=e.bit_count(),syndrome_weight=0,outside_stabilizer_rowspace=True)
        print('PASS:',s,'upper bound',e.bit_count(),'support (zero based)',support(e))
    out=base/('cluster_check_'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print('Saved',out,'(upper bounds only)')
if __name__=='__main__': main()
