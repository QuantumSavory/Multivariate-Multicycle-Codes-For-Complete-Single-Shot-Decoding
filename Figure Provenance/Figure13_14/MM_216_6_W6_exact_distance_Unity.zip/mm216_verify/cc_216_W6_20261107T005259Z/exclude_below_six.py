from itertools import combinations
from pathlib import Path
from hashlib import sha256

def load(path):
    data = Path(path).read_bytes()
    print(path, "sha256:", sha256(data).hexdigest(), flush=True)
    lines = [s for s in data.decode().splitlines()
             if s.strip() and not s.startswith("%")]
    m, n, nz = map(int, lines[0].split())
    assert (m, n, nz) == (144, 216, 864)
    assert len(lines) == nz + 1
    rows = [0] * m
    for line in lines[1:]:
        i, j, value = map(int, line.split())
        assert 1 <= i <= m and 1 <= j <= n and value == 1
        bit = 1 << (j - 1)
        assert not rows[i - 1] & bit
        rows[i - 1] |= bit
    assert all(r.bit_count() == 6 for r in rows)
    return rows

def reduce_vector(x, pivots):
    while x and x.bit_length() in pivots:
        x ^= pivots[x.bit_length()]
    return x

def audit(sector, checks, stabilizers, witness):
    pivots = {}
    for row in stabilizers:
        r = reduce_vector(row, pivots)
        if r:
            pivots[r.bit_length()] = r
    assert len(pivots) == 105

    def syndrome(e):
        return sum(((h & e).bit_count() % 2) << j
                   for j, h in enumerate(checks))

    bits = [1 << i for i in range(216)]
    cols = [syndrome(b) for b in bits]
    e6 = sum(bits[i] for i in witness)
    assert e6.bit_count() == 6 and syndrome(e6) == 0
    assert reduce_vector(e6, pivots) != 0

    # One representative per syndrome suffices after checking that
    # every other small support in its bucket differs by a stabilizer.
    small = {0: 0}
    def check_collision(a, b):
        e = a ^ b
        if reduce_vector(e, pivots):
            support = [i for i in range(216) if e >> i & 1]
            raise SystemExit(f"Found lighter {sector} logical: {support}")

    for i in range(216):
        check_collision(bits[i], small.setdefault(cols[i], bits[i]))
    for i, j in combinations(range(216), 2):
        e = bits[i] | bits[j]
        s = cols[i] ^ cols[j]
        check_collision(e, small.setdefault(s, e))

    triples = 0
    for i, j, k in combinations(range(216), 3):
        triples += 1
        rep = small.get(cols[i] ^ cols[j] ^ cols[k])
        if rep is not None:
            check_collision(bits[i] | bits[j] | bits[k], rep)

    print(f"PASS d{sector}=6: checked {triples} triples against all "
          "supports of size 0–2; excluded weights 1–5; "
          f"verified weight-6 support {witness}", flush=True)

hx, hz = load("HX.mtx"), load("HZ.mtx")
assert all((x & z).bit_count() % 2 == 0 for x in hx for z in hz)
audit("X", hz, hx, [36, 39, 42, 54, 57, 60])
audit("Z", hx, hz, [144, 147, 150, 162, 165, 168])
